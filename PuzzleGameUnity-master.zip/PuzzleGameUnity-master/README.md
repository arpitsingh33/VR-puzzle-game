[![unofficial Google Analytics for GitHub](https://gaforgithub.azurewebsites.net/api?repo=PuzzleGameUnity)](https://github.com/dgkanatsios/gaforgithub)

# PuzzleGameUnity

![Puzzle game](http://studentguru.gr/cfs-file/__key/communityserver-blogs-components-weblogfiles/00-00-00-00-89-metablogapi/image_5F00_545B3F34.png)

Source code for a Puzzle Game built in Unity. You can check a blog post [here](http://dgkanatsios.com/2014/07/01/simple-puzzle-game-in-unity-source-code-provided-3/) whereas you can play the game [here](http://unitysamples.azurewebsites.net/simplepuzzlegame/).
